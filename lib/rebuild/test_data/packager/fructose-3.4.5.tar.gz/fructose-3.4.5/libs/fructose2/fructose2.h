#ifndef fructose2_h__
#define fructose2_h__

#include <fructose1/fructose1.h>

extern int fructose2_foo(int x);
extern int fructose2_bar(int x);

#endif /* fructose2_h__ */

