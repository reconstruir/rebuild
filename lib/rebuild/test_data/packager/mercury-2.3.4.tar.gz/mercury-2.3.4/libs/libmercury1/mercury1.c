#include "mercury1.h"

int mercury1_foo(int x)
{
  return 666 + x;
}

int mercury1_bar(int x)
{
  return 1000 + x;
}

