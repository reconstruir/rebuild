#include "mercury2.h"

int mercury2_foo(int x)
{
  return 666 + x;
}

int mercury2_bar(int x)
{
  return 1000 + x;
}

