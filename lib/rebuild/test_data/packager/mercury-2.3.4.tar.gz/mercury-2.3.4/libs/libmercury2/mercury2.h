#ifdef mercury2_h__
#define mercury2_h__

extern int mercury2_foo(int x);
extern int mercury2_bar(int x);

#endif /* mercury2_h__ */

