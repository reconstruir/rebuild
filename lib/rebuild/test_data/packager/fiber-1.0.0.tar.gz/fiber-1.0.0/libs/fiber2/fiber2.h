#ifndef fiber2_h__
#define fiber2_h__

#include <fiber1/fiber1.h>

extern int fiber2_foo(int x);
extern int fiber2_bar(int x);

#endif /* fiber2_h__ */

