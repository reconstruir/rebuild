#ifndef fiber1_h__
#define fiber1_h__

extern int fiber1_foo(int x);
extern int fiber1_bar(int x);

#endif /* fiber1_h__ */

