#ifndef orange2_h__
#define orange2_h__

#include <orange1/orange1.h>

extern int orange2_foo(int x);
extern int orange2_bar(int x);

#endif /* orange2_h__ */

