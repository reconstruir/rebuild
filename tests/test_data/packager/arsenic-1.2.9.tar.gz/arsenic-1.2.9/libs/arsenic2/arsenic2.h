#ifndef arsenic2_h__
#define arsenic2_h__

#include <arsenic1/arsenic1.h>

extern int arsenic2_foo(int x);
extern int arsenic2_bar(int x);

#endif /* arsenic2_h__ */

