#include "arsenic2.h"

int arsenic2_foo(int x)
{
  return arsenic1_foo(1000);
}

int arsenic2_bar(int x)
{
  return arsenic2_foo(2000);
}

