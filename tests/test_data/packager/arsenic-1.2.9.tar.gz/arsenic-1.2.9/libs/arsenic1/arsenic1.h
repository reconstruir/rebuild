#ifndef arsenic1_h__
#define arsenic1_h__

extern int arsenic1_foo(int x);
extern int arsenic1_bar(int x);

#endif /* arsenic1_h__ */

