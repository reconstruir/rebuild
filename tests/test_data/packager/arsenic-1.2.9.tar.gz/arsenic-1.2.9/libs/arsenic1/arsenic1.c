#include "arsenic1.h"

int arsenic1_foo(int x)
{
  return 100;
}

int arsenic1_bar(int x)
{
  return 200;
}

