#ifndef orange1_h__
#define orange1_h__

extern int orange1_foo(int x);
extern int orange1_bar(int x);

#endif /* orange1_h__ */

