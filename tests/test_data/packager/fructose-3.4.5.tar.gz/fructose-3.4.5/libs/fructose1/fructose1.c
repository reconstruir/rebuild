#include "fructose1.h"

int fructose1_foo(int x)
{
  return 100;
}

int fructose1_bar(int x)
{
  return 200;
}

