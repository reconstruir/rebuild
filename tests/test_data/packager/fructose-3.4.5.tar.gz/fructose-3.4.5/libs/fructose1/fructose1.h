#ifndef fructose1_h__
#define fructose1_h__

extern int fructose1_foo(int x);
extern int fructose1_bar(int x);

#endif /* fructose1_h__ */

