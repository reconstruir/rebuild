#ifndef template2_h__
#define template2_h__

#include <template1/template1.h>

extern int template2_foo(int x);
extern int template2_bar(int x);

#endif /* template2_h__ */

