#include "template1.h"

int template1_foo(int x)
{
  return 100;
}

int template1_bar(int x)
{
  return 200;
}

