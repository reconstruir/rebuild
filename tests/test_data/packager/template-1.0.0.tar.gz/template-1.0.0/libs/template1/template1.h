#ifndef template1_h__
#define template1_h__

extern int template1_foo(int x);
extern int template1_bar(int x);

#endif /* template1_h__ */

