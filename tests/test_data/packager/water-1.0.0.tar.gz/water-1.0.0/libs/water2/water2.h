#ifndef water2_h__
#define water2_h__

#include <water1/water1.h>

extern int water2_foo(int x);
extern int water2_bar(int x);

#endif /* water2_h__ */

