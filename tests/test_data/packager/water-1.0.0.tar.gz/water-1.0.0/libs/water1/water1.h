#ifndef water1_h__
#define water1_h__

extern int water1_foo(int x);
extern int water1_bar(int x);

#endif /* water1_h__ */

