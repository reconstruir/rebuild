#include "water1.h"

int water1_foo(int x)
{
  return 100;
}

int water1_bar(int x)
{
  return 200;
}

