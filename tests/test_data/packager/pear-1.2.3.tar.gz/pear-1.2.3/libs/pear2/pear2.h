#ifndef pear2_h__
#define pear2_h__

#include <pear1/pear1.h>

extern int pear2_foo(int x);
extern int pear2_bar(int x);

#endif /* pear2_h__ */

