#ifndef pear1_h__
#define pear1_h__

extern int pear1_foo(int x);
extern int pear1_bar(int x);

#endif /* pear1_h__ */

