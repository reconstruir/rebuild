#include "pear1.h"

#include <fructose1/fructose1.h>

int pear1_foo(int x)
{
  return fructose1_foo(10000);
}

int pear1_bar(int x)
{
  return fructose1_foo(10200);
}

