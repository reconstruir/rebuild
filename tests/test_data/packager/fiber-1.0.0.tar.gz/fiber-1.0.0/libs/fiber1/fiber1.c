#include "fiber1.h"

int fiber1_foo(int x)
{
  return 100;
}

int fiber1_bar(int x)
{
  return 200;
}

