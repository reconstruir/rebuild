#ifndef fruit2_h__
#define fruit2_h__

#include <fruit1/fruit1.h>

extern int fruit2_foo(int x);
extern int fruit2_bar(int x);

#endif /* fruit2_h__ */

