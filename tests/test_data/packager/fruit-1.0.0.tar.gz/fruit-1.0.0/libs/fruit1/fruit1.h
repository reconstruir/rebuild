#ifndef fruit1_h__
#define fruit1_h__

extern int fruit1_foo(int x);
extern int fruit1_bar(int x);

#endif /* fruit1_h__ */

