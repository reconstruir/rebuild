#include "apple1.h"

int apple1_foo(int x)
{
  return 100;
}

int apple1_bar(int x)
{
  return 200;
}

