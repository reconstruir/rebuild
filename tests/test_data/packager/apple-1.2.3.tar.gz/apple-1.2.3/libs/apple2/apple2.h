#ifndef apple2_h__
#define apple2_h__

#include <apple1/apple1.h>

extern int apple2_foo(int x);
extern int apple2_bar(int x);

#endif /* apple2_h__ */

