#include "apple2.h"

int apple2_foo(int x)
{
  return apple1_foo(1000);
}

int apple2_bar(int x)
{
  return apple2_foo(2000);
}

