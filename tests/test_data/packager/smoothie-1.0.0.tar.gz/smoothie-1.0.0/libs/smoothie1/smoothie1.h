#ifndef smoothie1_h__
#define smoothie1_h__

extern int smoothie1_foo(int x);
extern int smoothie1_bar(int x);

#endif /* smoothie1_h__ */

