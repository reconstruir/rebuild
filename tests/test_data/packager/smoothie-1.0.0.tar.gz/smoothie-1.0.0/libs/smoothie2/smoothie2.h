#ifndef smoothie2_h__
#define smoothie2_h__

#include <smoothie1/smoothie1.h>

extern int smoothie2_foo(int x);
extern int smoothie2_bar(int x);

#endif /* smoothie2_h__ */

