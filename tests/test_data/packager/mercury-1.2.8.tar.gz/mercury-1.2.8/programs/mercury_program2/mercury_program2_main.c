#include <config.h>
#include <stdio.h>

int main()
{
  printf("%s\n", PACKAGE_STRING);
  return 0;
}
