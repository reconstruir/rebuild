#ifndef mercury1_h__
#define mercury1_h__

extern int mercury1_foo(int x);
extern int mercury1_bar(int x);

#endif /* mercury1_h__ */

