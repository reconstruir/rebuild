#include "mercury1.h"

int mercury1_foo(int x)
{
  return 100;
}

int mercury1_bar(int x)
{
  return 200;
}

