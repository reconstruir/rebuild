#include "mercury2.h"

int mercury2_foo(int x)
{
  return mercury1_foo(1000);
}

int mercury2_bar(int x)
{
  return mercury2_foo(2000);
}

