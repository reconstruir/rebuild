#ifndef mercury2_h__
#define mercury2_h__

#include <mercury1/mercury1.h>

extern int mercury2_foo(int x);
extern int mercury2_bar(int x);

#endif /* mercury2_h__ */

