#ifndef apple1_h__
#define apple1_h__

extern int apple1_foo(int x);
extern int apple1_bar(int x);

#endif /* apple1_h__ */

